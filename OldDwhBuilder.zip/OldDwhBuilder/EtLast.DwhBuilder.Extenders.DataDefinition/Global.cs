﻿global using System;
global using System.Globalization;
global using System.Linq;
global using FizzCode.DbTools.DataDefinition;
global using FizzCode.LightWeight.Collections;
global using FizzCode.LightWeight.RelationalModel;
