﻿global using System.Collections.Generic;
global using System.Linq;
global using FizzCode.DbTools.DataDefinition;
global using FizzCode.DbTools.DataDefinition.MsSql2016;