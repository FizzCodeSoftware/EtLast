﻿global using System;
global using System.Collections.Generic;
global using System.Diagnostics;
global using System.Globalization;
global using System.Linq;
global using FizzCode.LightWeight.AdoNet;
global using FizzCode.LightWeight.RelationalModel;