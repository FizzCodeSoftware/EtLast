﻿global using System.Linq;
global using FizzCode.DbTools.DataDefinition;
global using FizzCode.DbTools.DataDefinition.MsSql2016;
global using FizzCode.EtLast.DwhBuilder;
global using FizzCode.EtLast.DwhBuilder.Extenders.DataDefinition;
global using FizzCode.EtLast.DwhBuilder.Extenders.DataDefinition.MsSql;
global using FizzCode.LightWeight.RelationalModel;
global using Microsoft.VisualStudio.TestTools.UnitTesting;